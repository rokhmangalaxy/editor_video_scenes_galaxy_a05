package com.pribadi.editorvideo.export

import com.pribadi.editorvideo.model.Seg
import com.pribadi.editorvideo.model.VideoInfo

enum class ExportMode { VIDEO, ALL, CURRENT }

/** Semua yang dibutuhkan untuk mengekspor (snapshot dari editor saat tombol Mulai Ekspor ditekan). */
data class ExportRequest(
    val sourceUri: String,
    val info: VideoInfo,
    val segs: List<Seg>,
    val currentIndex: Int,
    val rot: Int,
    val flip: Boolean,
    val text1: String,
    val text2: String,
    val qIdx: Int,
    val fIdx: Int,
    val mode: ExportMode
)

/** Satu file keluaran: sufiks nama file dan potongan yang dimuat. */
data class OutputJob(val suffix: String, val segs: List<Seg>)
