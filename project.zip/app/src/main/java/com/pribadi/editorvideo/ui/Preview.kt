package com.pribadi.editorvideo.ui

import android.graphics.Paint
import android.graphics.Typeface
import android.view.Gravity
import android.view.TextureView
import android.widget.FrameLayout
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.pribadi.editorvideo.export.OverlayRenderer
import com.pribadi.editorvideo.vm.EditorViewModel
import kotlinx.coroutines.delay
import kotlin.math.hypot

/**
 * Kotak pratinjau: video (atau adegan demo), dua teks overlay yang bisa diketuk, dan petunjuk impor.
 * boxW x boxH sudah mengikuti rasio video yang sudah diputar.
 */
@Composable
fun PreviewBox(
    vm: EditorViewModel,
    boxW: Dp,
    boxH: Dp,
    onEditText: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(boxW, boxH)
            .background(Color(0xFFE9ECEC))
    ) {
        if (vm.hasVideo) {
            VideoSurface(vm, boxW, boxH)
        } else {
            DemoScene()
        }
        OverlayLayer(vm, onEditText)
        if (vm.hint) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x8C000000))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(text = "Ketuk + untuk impor video", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

/**
 * TextureView dibuat seukuran video sebelum diputar, lalu diputar/dicermin lewat properti View.
 * Cermin dipasang setelah putar: pada rotasi 90/270 sumbu cermin berpindah ke Y (sebelum rotasi).
 */
@Composable
private fun VideoSurface(vm: EditorViewModel, boxW: Dp, boxH: Dp) {
    val rot = vm.rot
    val flip = vm.flip
    val r90 = rot % 180 != 0
    val preW = if (r90) boxH else boxW
    val preH = if (r90) boxW else boxH
    val density = LocalDensity.current
    val wPx = with(density) { preW.roundToPx() }
    val hPx = with(density) { preH.roundToPx() }

    // TextureView baru masih hitam sampai ada frame yang dirender; minta pemutar menggambar ulang frame saat ini.
    LaunchedEffect(Unit) {
        delay(250)
        vm.refreshFrame()
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            val frame = FrameLayout(ctx)
            frame.clipChildren = false
            frame.clipToPadding = false
            val tv = TextureView(ctx)
            frame.addView(tv, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
            vm.player.setVideoTextureView(tv)
            frame
        },
        update = { frame ->
            val tv = frame.getChildAt(0) as TextureView
            val lp = tv.layoutParams as FrameLayout.LayoutParams
            if (lp.width != wPx || lp.height != hPx) {
                lp.width = wPx
                lp.height = hPx
                tv.layoutParams = lp
            }
            tv.rotation = rot.toFloat()
            tv.scaleX = if (flip && !r90) -1f else 1f
            tv.scaleY = if (flip && r90) -1f else 1f
        },
        onRelease = { frame ->
            vm.player.clearVideoTextureView(frame.getChildAt(0) as TextureView)
        }
    )
}

/** Dua teks overlay digambar dengan kode yang sama seperti saat ekspor. Ketuk teks untuk mengubahnya. */
@Composable
private fun OverlayLayer(vm: EditorViewModel, onEditText: (Int) -> Unit) {
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    val hit = OverlayRenderer.hitTest(
                        size.width.toFloat(),
                        size.height.toFloat(),
                        vm.text1,
                        vm.text2,
                        pos.x,
                        pos.y,
                        12.dp.toPx()
                    )
                    if (hit != 0) onEditText(hit)
                }
            }
    ) {
        val t1 = vm.text1
        val t2 = vm.text2
        drawIntoCanvas { c ->
            OverlayRenderer.draw(c.nativeCanvas, size.width, size.height, t1, t2)
        }
    }
}

/** Adegan demo (dua gelas) yang tampil sebelum ada video, meniru .demo di HTML. */
@Composable
private fun DemoScene() {
    val d = LocalDensity.current.density
    val textPaint = remember(d) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, 800, false)
            textSize = 28f * d
            textAlign = Paint.Align.CENTER
        }
    }
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // linear-gradient(#eef1f1, #d5dada)
        drawRect(brush = Brush.verticalGradient(listOf(Color(0xFFEEF1F1), Color(0xFFD5DADA))))

        // radial-gradient(circle at 75% 60%, #f4f6f6 0, transparent 50%)
        val c2 = Offset(w * 0.75f, h * 0.60f)
        val far2 = maxOf(
            hypot(c2.x, c2.y), hypot(w - c2.x, c2.y), hypot(c2.x, h - c2.y), hypot(w - c2.x, h - c2.y)
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFF4F6F6), Color(0x00F4F6F6)),
                center = c2,
                radius = far2 * 0.50f
            )
        )

        // radial-gradient(circle at 30% 70%, #d8dede 0, transparent 45%)
        val c1 = Offset(w * 0.30f, h * 0.70f)
        val far1 = maxOf(
            hypot(c1.x, c1.y), hypot(w - c1.x, c1.y), hypot(c1.x, h - c1.y), hypot(w - c1.x, h - c1.y)
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFD8DEDE), Color(0x00D8DEDE)),
                center = c1,
                radius = far1 * 0.45f
            )
        )

        // dua gelas
        val cupW = w * 0.34f
        val cupH = h * 0.24f
        val cupTop = h * (1f - 0.18f) - cupH
        val leftA = w * 0.10f
        val leftB = w * (1f - 0.10f) - cupW
        val r6 = 6f * d
        val r18 = 18f * d
        for (n in 0 until 2) {
            val left = if (n == 0) leftA else leftB
            val rr = RoundRect(
                rect = Rect(left, cupTop, left + cupW, cupTop + cupH),
                topLeft = CornerRadius(r6, r6),
                topRight = CornerRadius(r6, r6),
                bottomRight = CornerRadius(r18, r18),
                bottomLeft = CornerRadius(r18, r18)
            )
            val path = Path()
            path.addRoundRect(rr)
            drawPath(path, Color(0x8CFFFFFF))
            drawPath(path, Color(0x99A0AAAF), style = Stroke(width = 2f * d))
        }

        drawIntoCanvas { c ->
            val fm = textPaint.fontMetrics
            val cy = cupTop + cupH / 2f - (fm.ascent + fm.descent) / 2f
            textPaint.color = 0xFF3A4F8F.toInt()
            c.nativeCanvas.drawText("aq", leftA + cupW / 2f, cy, textPaint)
            textPaint.color = 0xFFC8A21A.toInt()
            c.nativeCanvas.drawText("AQ", leftB + cupW / 2f, cy, textPaint)
        }
    }
}
