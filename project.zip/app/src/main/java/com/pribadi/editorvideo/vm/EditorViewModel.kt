package com.pribadi.editorvideo.vm

import android.app.Application
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.Choreographer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import com.pribadi.editorvideo.export.EncoderCaps
import com.pribadi.editorvideo.export.ExportCenter
import com.pribadi.editorvideo.export.ExportMath
import com.pribadi.editorvideo.export.ExportMode
import com.pribadi.editorvideo.export.ExportPlan
import com.pribadi.editorvideo.export.ExportPlanner
import com.pribadi.editorvideo.export.ExportRequest
import com.pribadi.editorvideo.export.ExportState
import com.pribadi.editorvideo.export.VideoFrames
import com.pribadi.editorvideo.export.VideoProbe
import com.pribadi.editorvideo.model.EditorCore
import com.pribadi.editorvideo.model.Fmt
import com.pribadi.editorvideo.model.Rules
import com.pribadi.editorvideo.model.VideoInfo
import com.pribadi.editorvideo.model.clampD
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Alat di bar bawah. */
enum class Tool { SPLIT, SPEED, DUP, DEL, ROTATE, MIRROR, FREEZE, REVERSE }

/** Data untuk sheet ekspor. */
data class ExportInfo(
    val plan: ExportPlan,
    val mb: Double,
    val subVideo: String,
    val subAll: String,
    val subCurrent: String
)

/**
 * Jembatan antara UI Compose, logika editor (EditorCore), pemutar pratinjau (ExoPlayer)
 * dan ekspor. Semua fungsi dipanggil dari thread utama.
 *
 * Perubahan data editor tidak otomatis memicu Compose, jadi:
 *  - [rev] dinaikkan setiap kali ada perubahan yang perlu digambar ulang (dibaca oleh Canvas),
 *  - properti state lain (rot, flip, selSpeed, ...) hanya berubah saat nilainya benar-benar berubah.
 */
class EditorViewModel(app: Application) : AndroidViewModel(app) {

    val core = EditorCore()
    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    // ------------------------------------------------------------------ state untuk UI

    /** Pemicu gambar ulang Canvas (timeline, teks overlay). */
    var rev by mutableIntStateOf(0)
        private set

    var playing by mutableStateOf(false)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var rot by mutableIntStateOf(0)
        private set
    var flip by mutableStateOf(false)
        private set
    var selSpeed by mutableDoubleStateOf(1.0)
        private set
    var selIndex by mutableIntStateOf(0)
        private set
    var segCount by mutableIntStateOf(1)
        private set
    var hasVideo by mutableStateOf(false)
        private set
    var hint by mutableStateOf(true)
        private set
    var info by mutableStateOf<VideoInfo?>(null)
        private set

    var text1 by mutableStateOf("sini merapat")
        private set
    var text2 by mutableStateOf("@NAMAKAMU")
        private set

    /** Zoom timeline (dp per detik). */
    var pps by mutableDoubleStateOf(Rules.PPS0)
        private set
    var zoomTag by mutableStateOf<String?>(null)
        private set

    var toastMsg by mutableStateOf<String?>(null)
        private set

    var speedSheet by mutableStateOf(false)
    var confirmText by mutableStateOf<String?>(null)
    var exportSheet by mutableStateOf(false)
    var fullscreen by mutableStateOf(false)

    /** 0 = tidak ada, 1 = teks atas, 2 = teks bawah. */
    var editingText by mutableIntStateOf(0)

    var exportMode by mutableStateOf(ExportMode.VIDEO)
    var qIdx by mutableIntStateOf(ExportMath.DEFAULT_QUALITY)
    var fIdx by mutableIntStateOf(ExportMath.DEFAULT_FPS)

    val exportState = ExportCenter.state

    // ------------------------------------------------------------------ internal

    private var sourceUri: Uri? = null
    private var curSeg = 0
    private var lastNanos = 0L
    private var toastJob: Job? = null
    private var zoomJob: Job? = null
    private var importJob: Job? = null
    private var thumbJob: Job? = null

    private var thumbs: Array<Bitmap?> = arrayOfNulls(0)
    private var thumbReady = 0

    private val choreographer: Choreographer = Choreographer.getInstance()
    private val frameCallback = Choreographer.FrameCallback { ts -> tick(ts) }

    init {
        core.onPause = { pause() }
        player.playWhenReady = false
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                pause()
                toast("Video tidak bisa diputar")
            }
        })
        viewModelScope.launch {
            ExportCenter.state.collect { st ->
                if (st is ExportState.Cancelled) {
                    toast("Ekspor dibatalkan")
                    ExportCenter.reset()
                }
            }
        }
        // Activity dibuka lagi saat ekspor masih berjalan (mis. dari notifikasi): tampilkan progresnya.
        if (ExportCenter.isRunning()) exportSheet = true
        refreshDerived()
    }

    override fun onCleared() {
        choreographer.removeFrameCallback(frameCallback)
        thumbJob?.cancel()
        importJob?.cancel()
        try {
            player.release()
        } catch (e: Exception) {
            // diabaikan
        }
        super.onCleared()
    }

    private fun bump() {
        rev = rev + 1
    }

    private fun refreshDerived() {
        canUndo = core.canUndo
        canRedo = core.canRedo
        rot = core.rot
        flip = core.flip
        selIndex = core.sel
        selSpeed = core.selSpeed
        segCount = core.segs.size
    }

    fun toast(msg: String) {
        toastMsg = msg
        toastJob?.cancel()
        toastJob = viewModelScope.launch {
            delay(1800)
            toastMsg = null
        }
    }

    // ------------------------------------------------------------------ pemutar

    private fun seekPlayerTo(sec: Double, tol: Double) {
        if (!hasVideo) return
        val cur = player.currentPosition / 1000.0
        if (abs(cur - sec) > tol) player.seekTo(Math.round(max(0.0, sec) * 1000.0))
    }

    /** Padanan seekVideoToEdit() di HTML. */
    private fun seekVideoToEdit() {
        val l = core.locate(core.t)
        curSeg = l.i
        seekPlayerTo(l.s, 0.03)
    }

    private fun setSeekFast(fast: Boolean) {
        player.setSeekParameters(if (fast) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
    }

    /** Menggambar ulang frame pratinjau (setelah permukaan video dibuat ulang). */
    fun refreshFrame() {
        if (hasVideo && !playing) {
            try {
                player.seekTo(player.currentPosition)
            } catch (e: Exception) {
                // diabaikan
            }
        }
    }

    fun togglePlay() {
        if (playing) pause() else play()
    }

    fun play() {
        if (playing) return
        if (core.t >= core.total - 0.02) core.t = 0.0
        val l = core.locate(core.t)
        val g = core.segs[l.i]
        curSeg = l.i
        playing = true
        hint = false
        if (hasVideo) {
            setSeekFast(false)
            seekPlayerTo(l.s, 0.03)
            if (g.fz) {
                player.pause()
            } else {
                player.setPlaybackSpeed(g.sp.toFloat())
                player.play()
            }
        }
        lastNanos = System.nanoTime()
        choreographer.removeFrameCallback(frameCallback)
        choreographer.postFrameCallback(frameCallback)
        bump()
    }

    fun pause() {
        if (!playing) return
        playing = false
        choreographer.removeFrameCallback(frameCallback)
        if (hasVideo) player.pause()
        bump()
    }

    private fun endPlay() {
        playing = false
        choreographer.removeFrameCallback(frameCallback)
        if (hasVideo) player.pause()
        core.t = min(core.t, core.total)
        core.sync()
        refreshDerived()
        bump()
    }

    private fun enterSeg(i: Int) {
        curSeg = i
        val g = core.segs[i]
        if (!hasVideo) return
        if (g.fz) {
            player.pause()
            seekPlayerTo(g.a, 0.03)
            return
        }
        player.setPlaybackSpeed(g.sp.toFloat())
        seekPlayerTo(g.a, 0.08)
        player.play()
    }

    private fun tick(ts: Long) {
        if (!playing) return
        var dt = (ts - lastNanos) / 1e9
        lastNanos = ts
        if (dt < 0.0) dt = 0.0
        if (dt > 0.1) dt = 0.1
        val segs = core.segs
        if (curSeg >= segs.size) curSeg = segs.size - 1
        val g = segs[curSeg]
        var adv = false
        if (g.fz || !hasVideo) {
            core.t = core.t + dt
            if (core.t >= core.lay.off[curSeg] + g.len - 1e-6) adv = true
        } else {
            val s = player.currentPosition / 1000.0
            if (s >= g.b - 0.03 || player.playbackState == Player.STATE_ENDED) {
                adv = true
            } else {
                core.t = core.lay.off[curSeg] + max(0.0, s - g.a) / g.sp
            }
        }
        if (adv) {
            if (curSeg < segs.size - 1) {
                enterSeg(curSeg + 1)
                core.t = core.lay.off[curSeg]
            } else {
                core.t = core.total
                endPlay()
                return
            }
        }
        core.sync()
        refreshDerived()
        bump()
        choreographer.postFrameCallback(frameCallback)
    }

    // ------------------------------------------------------------------ timeline: scrub, ketuk, zoom, trim

    /** Awal geseran timeline oleh jari: hentikan putar, pakai seek cepat. */
    fun scrubBegin() {
        pause()
        setSeekFast(true)
    }

    /** Menggeser playhead sebanyak dtSeconds detik timeline. */
    fun scrubBy(dtSeconds: Double) {
        core.setTime(core.t + dtSeconds)
        seekVideoToEdit()
        refreshDerived()
        bump()
    }

    /** Akhir geseran/fling: seek presisi ke posisi akhir. */
    fun scrubEnd() {
        setSeekFast(false)
        seekVideoToEdit()
        refreshDerived()
        bump()
    }

    /** Ketuk di timeline pada waktu tt (detik timeline). */
    fun tapAt(tt: Double) {
        if (tt < 0.0 || tt > core.total) return
        pause()
        setSeekFast(false)
        core.setTime(tt)
        seekVideoToEdit()
        refreshDerived()
        bump()
    }

    fun setZoom(p: Double) {
        val np = clampD(p, Rules.PPS_MIN, 320.0)
        if (np == pps) return
        pps = np
        zoomTag = "Zoom " + Fmt.one(np / Rules.PPS0) + "x"
        zoomJob?.cancel()
        zoomJob = viewModelScope.launch {
            delay(800)
            zoomTag = null
        }
        bump()
    }

    fun pinchBegin() {
        pause()
    }

    fun trimBegin(side: Int) {
        pause()
        setSeekFast(true)
        core.trimBegin(side)
        refreshDerived()
        bump()
    }

    fun trimMove(dxSeconds: Double) {
        core.trimMove(dxSeconds)
        if (hasVideo) {
            val g = core.trimSeg
            if (g != null && !g.fz) {
                if (core.trimmingSide == 1) {
                    player.seekTo(Math.round(g.a * 1000.0))
                } else {
                    player.seekTo(Math.round(max(g.b - 0.05, g.a) * 1000.0))
                }
            }
        }
        bump()
    }

    fun trimEnd() {
        core.trimEnd()
        setSeekFast(false)
        seekVideoToEdit()
        refreshDerived()
        bump()
    }

    // ------------------------------------------------------------------ riwayat

    fun undo() {
        if (core.undo()) afterHistory()
    }

    fun redo() {
        if (core.redo()) afterHistory()
    }

    private fun afterHistory() {
        refreshDerived()
        setSeekFast(false)
        seekVideoToEdit()
        bump()
    }

    // ------------------------------------------------------------------ alat

    fun onTool(tool: Tool) {
        when (tool) {
            Tool.SPLIT -> {
                val msg = core.split()
                refreshDerived()
                bump()
                if (msg != null) toast(msg)
            }

            Tool.SPEED -> {
                refreshDerived()
                speedSheet = true
            }

            Tool.DUP -> {
                val msg = core.duplicate()
                refreshDerived()
                bump()
                if (msg != null) toast(msg)
            }

            Tool.DEL -> {
                val msg = core.delete()
                refreshDerived()
                setSeekFast(false)
                seekVideoToEdit()
                bump()
                if (msg != null) toast(msg)
            }

            Tool.ROTATE -> {
                core.rotate()
                refreshDerived()
                bump()
            }

            Tool.MIRROR -> {
                val msg = core.mirror()
                refreshDerived()
                bump()
                toast(msg)
            }

            Tool.FREEZE -> {
                val msg = core.freezeFrame()
                refreshDerived()
                setSeekFast(false)
                seekVideoToEdit()
                bump()
                if (msg != null) toast(msg)
            }

            Tool.REVERSE -> toast("Membalikkan klip belum tersedia")
        }
    }

    // ------------------------------------------------------------------ kecepatan

    fun setSpeed(v: Double, commit: Boolean) {
        val msg = core.setSpeed(v, commit)
        if (playing && curSeg == core.sel && hasVideo) player.setPlaybackSpeed(core.selSpeed.toFloat())
        refreshDerived()
        bump()
        if (msg != null) toast(msg)
    }

    /** Slider selesai digeser: simpan ke riwayat bila ada perubahan. */
    fun commitSpeed() {
        core.commitIfChanged()
        refreshDerived()
    }

    fun askApplyAll() {
        if (core.segs.size < 2) {
            toast("Hanya ada satu potongan")
            return
        }
        confirmText = core.applyAllText()
    }

    fun confirmApplyAll() {
        val msg = core.applySpeedAll()
        confirmText = null
        refreshDerived()
        setSeekFast(false)
        seekVideoToEdit()
        bump()
        toast(msg)
    }

    // ------------------------------------------------------------------ teks overlay

    fun applyText(which: Int, v: String) {
        if (v.trim().isEmpty()) return
        if (which == 1) text1 = v else if (which == 2) text2 = v
        bump()
    }

    // ------------------------------------------------------------------ impor

    fun importVideo(uri: Uri) {
        importJob?.cancel()
        importJob = viewModelScope.launch {
            pause()
            val ctx = getApplication<Application>()
            val inf = withContext(Dispatchers.IO) { VideoProbe.probe(ctx, uri) }
            if (inf == null || inf.durationMs <= 0L) {
                toast("Durasi video tidak terbaca")
                return@launch
            }
            info = inf
            sourceUri = uri
            core.loadVideo(inf.durationMs / 1000.0)
            pps = Rules.PPS0
            hasVideo = true
            hint = false
            curSeg = 0
            setSeekFast(false)
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.pause()
            refreshDerived()
            bump()
            toast("Video diimpor")
            startThumbs(uri, inf)
        }
    }

    private fun startThumbs(uri: Uri, inf: VideoInfo) {
        thumbJob?.cancel()
        val dur = inf.durationMs / 1000.0
        val uniq = min(150, max(10, ceil(dur * 3.0).toInt()))
        val arr = arrayOfNulls<Bitmap>(uniq)
        thumbs = arr
        thumbReady = 0
        bump()
        thumbJob = viewModelScope.launch(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(getApplication<Application>(), uri)
                var prev: Bitmap? = null
                for (i in 0 until uniq) {
                    ensureActive()
                    val sec = min(dur - 0.05, (i + 0.5) / uniq * dur)
                    val us = Math.round(max(0.0, sec) * 1_000_000.0)
                    var tile: Bitmap? = null
                    try {
                        val raw = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (raw != null) {
                            val up = VideoFrames.upright(raw, inf)
                            tile = VideoFrames.coverCrop(up, THUMB_W, THUMB_H)
                        }
                    } catch (e: Exception) {
                        tile = null
                    }
                    if (tile == null) tile = prev
                    arr[i] = tile
                    if (tile != null) prev = tile
                    if (i % 6 == 5 || i == uniq - 1) {
                        withContext(Dispatchers.Main) {
                            thumbReady = i + 1
                            bump()
                        }
                    }
                }
            } catch (e: Exception) {
                // thumbnail gagal: timeline tetap bisa dipakai dengan warna polos
            } finally {
                try {
                    r.release()
                } catch (e: Exception) {
                    // diabaikan
                }
            }
        }
    }

    /** Thumbnail terdekat untuk waktu sumber tertentu (detik), atau null bila belum siap. */
    fun thumbAt(time: Double): Bitmap? {
        val arr = thumbs
        if (arr.isEmpty() || thumbReady == 0) return null
        val dur = core.fullDur
        var k = floor(time / dur * arr.size).toInt()
        if (k < 0) k = 0
        if (k > arr.size - 1) k = arr.size - 1
        val direct = arr[k]
        if (direct != null) return direct
        var d = 1
        while (d < arr.size) {
            val a = k - d
            if (a >= 0) {
                val ba = arr[a]
                if (ba != null) return ba
            }
            val b = k + d
            if (b < arr.size) {
                val bb = arr[b]
                if (bb != null) return bb
            }
            d++
        }
        return null
    }

    // ------------------------------------------------------------------ layar penuh

    fun toggleFullscreen() {
        fullscreen = !fullscreen
    }

    // ------------------------------------------------------------------ ekspor

    private fun demoInfo(): VideoInfo = VideoInfo(9, 16, 0, 12200L, 30f, false)

    fun openExport() {
        pause()
        exportSheet = true
    }

    fun closeExport() {
        if (ExportCenter.isRunning()) {
            toast("Ekspor sedang berjalan")
            return
        }
        exportSheet = false
        ExportCenter.reset()
    }

    /** Ringkasan untuk sheet ekspor (ukuran, FPS efektif, perkiraan ukuran file, catatan fallback). */
    fun exportInfo(): ExportInfo {
        val inf = info ?: demoInfo()
        val plan = ExportPlanner.plan(inf, rot, qIdx, fIdx) { w, h -> EncoderCaps.supportsH264(w, h) }
        val cur = core.segs.getOrNull(core.sel)?.len ?: 0.0
        val dur = if (exportMode == ExportMode.CURRENT) cur else core.total
        val mb = ExportMath.estimateMB(plan.width, plan.height, plan.fps, dur)
        return ExportInfo(
            plan,
            mb,
            "1 file · " + Fmt.time(core.total),
            core.segs.size.toString() + " file · " + Fmt.time(core.total) + " total",
            "1 file · " + Fmt.time(cur)
        )
    }

    fun startExport() {
        val inf = info
        val uri = sourceUri
        if (!hasVideo || inf == null || uri == null) {
            toast("Impor video dulu sebelum ekspor")
            return
        }
        if (ExportCenter.isRunning()) return
        val req = ExportRequest(
            uri.toString(), inf, core.segs, core.sel, core.rot, core.flip,
            text1, text2, qIdx, fIdx, exportMode
        )
        val plan = ExportPlanner.plan(inf, core.rot, qIdx, fIdx) { w, h -> EncoderCaps.supportsH264(w, h) }
        ExportCenter.start(getApplication<Application>(), req, plan)
    }

    fun cancelExport() {
        ExportCenter.cancel()
    }

    companion object {
        const val THUMB_W = 128
        const val THUMB_H = 96
    }
}
